import time
import os
from extremely_serious_toaster import extremely_serious_toaster
from random import randint


def read_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read().strip()


def monitor_file(file_path):
    last_content = None
    last_entries = []
    displayed_entries = set()  # Для отслеживания уже показанных записей

    while True:
        current_content = read_file(file_path)

        if current_content != last_content:
            last_content = current_content
            print(f"Содержимое файла обновлено: {last_content}, корректный список: {last_entries}")

            # Добавляем новое содержимое в список последних записей
            if last_content not in last_entries:
                last_entries.append(last_content)

                # Ограничиваем список до 5 последних записей
                if len(last_entries) > 5:
                    last_entries.pop(0)

            # Отображаем новые записи в тостах
            new_entries = [entry for entry in last_entries if entry not in displayed_entries]

            if len(last_entries) < 5:
                # Если в списке меньше 5 элементов, показываем только новые
                for entry in new_entries:
                    extremely_serious_toaster(entry, randint(0, 10000))
                    displayed_entries.add(entry)
            else:
                # Если добавилось 5 элементов, показываем все
                for entry in last_entries:
                    if entry not in displayed_entries:
                        extremely_serious_toaster(entry, randint(0, 10000))
                        displayed_entries.add(entry)

        time.sleep(10)


if __name__ == "__main__":
    file_path = 'text.txt'

    if not os.path.exists(file_path):
        print(f"Файл {file_path} не найден.")
    else:
        monitor_file(file_path)