import json
import time
import streamlit as st
import random
from extremely_serious_toaster import extremely_serious_toaster
import hashlib

file_path = "signals2.json"
last_hash = None


def read_file(file_path):
    """Функция для чтения файла."""
    with open(file_path, 'r', encoding="utf-8") as file:
        return json.load(file)


def get_file_hash(file_path):
    """Функция для получения хэш-суммы файла."""
    hasher = hashlib.md5()
    with open(file_path, 'rb') as file:
        while chunk := file.read(8192):
            hasher.update(chunk)
    return hasher.hexdigest()


def check_for_updates():
    """Функция для проверки обновления json-файла."""
    global last_hash
    current_hash = get_file_hash(file_path)
    if last_hash is None:
        last_hash = current_hash
        return True

    if current_hash != last_hash:
        last_hash = current_hash
        print("Есть обновление в файле")
        return True  # Файл обновился

    return False  # Файл не обновился


def main():
    last_data = None

    with st.sidebar:
        if st.button('Мои уведомления'):
            all_entries = [item for sublist in read_file(file_path).values() if isinstance(sublist, list) for item in
                           sublist]
            for entry in all_entries:
                extremely_serious_toaster(f"<a href='https://clck.ru/3D2v4m'>{entry}</a>", time=0,
                                          key=random.randint(0, 10000))
                time.sleep(0.3)

    while True:
        if check_for_updates():
            current_data = read_file(file_path)

            if last_data is not None:
                for currency in current_data.keys():
                    new_values = list(set(current_data[currency]) - set(last_data.get(currency, [])))
                    if new_values:
                        for value in new_values:
                            extremely_serious_toaster(f"<a href='https://clck.ru/3D2v4m'>{value}</a>", time=0.3)
                            print(f"Новое значение для {currency}: {value}")

            last_data = current_data  # Обновляем сохраненные данные
            st.rerun()

        time.sleep(5)


if __name__ == "__main__":
    main()