import os
import streamlit.components.v1 as components

parent_dir = os.path.dirname(os.path.abspath(__file__))
build_dir = os.path.join(parent_dir, "build")
_component_func = components.declare_component("extremely_serious_toaster", path=build_dir)

def extremely_serious_toaster(name, maxWidth=150, time=0, key=None):
    component_value = _component_func(name=name, maxWidth=maxWidth, time=time, key=key)

    # We could modify the value returned from the component if we wanted.
    # There's no need to do this in our simple example - but it's an option.
    return component_value


